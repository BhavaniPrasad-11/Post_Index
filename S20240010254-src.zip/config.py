"""Configuration settings for Malayalam Positional Inverted Index.

This module centralizes filesystem paths, Wikimedia dump URLs,
database schemas, and indexing hyperparameters.
"""

from pathlib import Path

# Base project paths
BASE_DIR = Path(__file__).resolve().parent
SRC_DIR = BASE_DIR / "src"
DATA_DIR = BASE_DIR / "data"
INDEX_DIR = BASE_DIR / "index"
OUTPUT_DIR = BASE_DIR / "output"
TESTS_DIR = BASE_DIR / "tests"
SCRIPTS_DIR = BASE_DIR / "scripts"

# Dataset settings
WIKIPEDIA_DUMP_URL = "https://dumps.wikimedia.org/mlwiki/latest/mlwiki-latest-pages-articles.xml.bz2"
DUMP_FILENAME = "mlwiki-latest-pages-articles.xml.bz2"
DUMP_PATH = DATA_DIR / DUMP_FILENAME
COLLECTION_METADATA_FILE = DATA_DIR / "collection_info.json"

# Storage paths
POSTINGS_DB_PATH = INDEX_DIR / "postings.sqlite3"
DICTIONARY_FILE_PATH = INDEX_DIR / "dictionary.json"

# Output report paths
STATS_REPORT_PATH = OUTPUT_DIR / "collection_statistics.txt"
RARE_TERMS_REPORT_PATH = OUTPUT_DIR / "rare_terms.txt"
TEST_RESULTS_REPORT_PATH = OUTPUT_DIR / "test_results.txt"
QUERY_EXAMPLES_REPORT_PATH = OUTPUT_DIR / "query_examples.txt"
SAMPLE_INDEX_REPORT_PATH = OUTPUT_DIR / "sample_positional_index.txt"

# Indexing hyperparameters
# Commit postings to SQLite in batches of documents to bound RAM usage
BATCH_SIZE = 500

# Default limit of articles to index. Set to None to index the entire dump.
# Can be overridden via command-line arguments.
DEFAULT_MAX_DOCS = None

# Unicode and Normalization configuration
MALAYALAM_UNICODE_RANGE = (0x0D00, 0x0D7F)
ZWNJ = "\u200C"
ZWJ = "\u200D"

# Wikipedia base URL for Malayalam
WIKI_BASE_URL = "https://ml.wikipedia.org/wiki/"
